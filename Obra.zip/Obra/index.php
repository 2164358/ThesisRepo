<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

form {
  border: 3px solid black;  
  width: 30%; 
  margin-left: auto;
  margin-right: auto; 
  margin-top: 120px; 
  border-radius: 10px;
  box-shadow: 2px 2px 2px gray;
  background-color: #ff6d45; 
}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 1px 10px;
  border: none;
  border-radius: 50px 50px 50px 50px;
  cursor: pointer;
  width: 50%;
  margin-left: 110px;
}

button:hover {
  opacity: 0.8;
}

.input100 {
    font-family: Poppins-Regular;
    font-size: 15px;
    color: #555;
    line-height: 1.2;
    display: block;
    width: 100%;
    height: 45px;
    background: 0 0;
    padding: 0 5px;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 20px;
  margin-top: 10px;
}

span.psw {
  float: right;
  margin-top: 10px;
}

span.rem {
  float: left;
  margin-top: 10px;
}

p{
  font-size: 18px;
  font-family: "Times New Roman", Times, serif;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
}
</style>
</head>
<body>

<form action="/action_page.php">
  <div class="imgcontainer">
    <img src="FandD_logo.png" alt="Avatar" class="avatar">
  </div>

  <div class="container">
    <label for="uname"><b>Username</b></label>
    <input class="input100" type="text" placeholder="Enter Username" name="uname" required>

    <label for="psw"><b>Password</b></label>
    <input class="input100" type="password" placeholder="Enter Password" name="psw" required>
        
    <button type="submit"><p>Login</p></button>
    <!--<span class="psw">Forgot <a href="#">password?</a>
    </span>-->
    <span class="rem"><input type="checkbox" unchecked="checked" name="remember"> Remember me 
    </span>
  </div>

  <div class="container" style="background-color:black">
  </div>
</form>

</body>
</html>
