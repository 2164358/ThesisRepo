<?php


if(isset($_POST['delete']))
{
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $databaseName = "finaldatabase";
    
    // get id to delete
    $id = $_POST['id'];
    
    // connect to mysql
    $connect = mysqli_connect($localhost, $root, $password, $finaldatabase);
    
    // mysql delete query 
    $query = "DELETE FROM `users` WHERE `id` = $id";
    
    $result = mysqli_query($connect, $query);
    
    if($result)
    {
        echo 'Cancelled';
    }else{
        echo 'Not Cancelled';
    }
    mysqli_close($connect);
}

?>

<!DOCTYPE html>

<html>

    <head>

        <title> PHP CANCEL </title>

        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>

    <body>

        <form action="cancel.php" method="post">

            CANCEL:&nbsp;<input type="text" name="id" required><br><br>

            <input type="submit" name="cancel" value="Cancel Order">

        </form>

    </body>

</html>