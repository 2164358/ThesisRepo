<?php
$deduction = $_POST['deduction'];
$category = $_POST['status'];
if (!empty($deduction) || !empty($status)) {
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "finaldatabase";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     $SELECT = "SELECT * From deduction Where menu_name = ? Limit 1";
     $INSERT = "INSERT Into deduction (deduction, status) values(?, ?)";
     //Prepare statement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $menu_name);
     $stmt->execute();
     $stmt->bind_result($menu_name);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("ss", $menu_name, $status);
      $stmt->execute();
      header("Location: http://localhost/master/examples/cancel.php");
exit();
     } else {
      echo "Order Deduction";
     }
     $stmt->close();
     $conn->close();
    }
} else {
 echo "Fill all blanks";
 die();
}
