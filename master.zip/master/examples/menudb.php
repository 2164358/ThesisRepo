<?php
$item_name = $_POST['item_name'];
$category = $_POST['category'];
if (!empty($cancel_order) || !empty(category)) {
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "finaldatabase";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     $SELECT = "SELECT item_name From inventory Where item_name = ? Limit 1";
     $INSERT = "INSERT Into inventory (item_name, category) values(?, ?)";
     //Prepare statement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $item_name);
     $stmt->execute();
     $stmt->bind_result($item_name);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("ss", $cancel_order, $status);
      $stmt->execute();
      header("Location: http://localhost/master/examples/cancel.php");
exit();
     } else {
      echo "Items";
     }
     $stmt->close();
     $conn->close();
    }
} else {
 echo "Fill all blanks";
 die();
}
